from .views import router as faq_router  # Change '.faq' to '.views'

__all__ = ['faq_router']
